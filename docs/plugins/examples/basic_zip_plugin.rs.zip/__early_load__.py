#!/bin/python

'''This file is loaded by PluginManager.early_load_plugins()'''

#> Imports
import RS
#</Imports

#> Main >/
print(f'Hello {rs}, I\'m comin\' in early from a zip file!')
