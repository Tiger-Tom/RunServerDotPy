#!/bin/python

'''This file is loaded by PluginManager.load_plugins()'''

#> Imports
import RS
#</Imports

#> Main >/
print(f'Hello from a zip file, {RS}!')
def __start__(self):
    print(f'Nice to meet you, {RS}! My name is {self}, and I\'m in a zip file!')
